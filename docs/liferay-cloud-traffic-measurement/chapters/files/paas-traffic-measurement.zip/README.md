# Liferay PaaS traffic measurement

Splits the anonymous page views of a Liferay Cloud site into human and automated
traffic, from the webserver (nginx) access logs.

| Part | What it does |
|---|---|
| `webserver/LCP.json.snippet` | Turns access logging on and switches the webserver to a key=value log format with the request headers the classifier needs |
| `webserver/configs/common/conf.d/traffic-measurement.conf` | Defines `$tm_auth` and answers the beacon (`/_tm/b`) and honeypot (`/_tm/hp/`) URLs directly in nginx |
| `client-extensions/traffic-beacon` | Global JS that reports page load, interaction and `navigator.webdriver` to `/_tm/b` |
| `honeypot-link.html` | Hidden link to `/_tm/hp/` for the page footer |
| `scripts/fetch-enrichment.sh` | Downloads cloud provider ranges, Tor exit nodes and (optionally) MaxMind data. Run weekly |
| `scripts/classify_traffic.py` | Classifies page views and writes daily CSV summaries |
| `scripts/run-classifier.sh` | Runs the classifier for one UTC day of backed-up log files |
| `scripts/build_report.py` | Turns the classifier's CSV files into a self-contained HTML dashboard |
| `samples/sample-report.html` | Example dashboard, built from 30 days of synthetic traffic |
| `samples/make_sample_logs.py` | Generates the synthetic logs behind the sample, for demos |

The logs themselves are collected by the webserver log backup (`webserver-log-backup/`),
which writes one `.log.gz` file per UTC hour to S3. That backup accepts both the
default and this measurement log format.

## Deploying

Do this on a development environment first, then UAT, then production.

1. **Webserver config and log format, in one deployment.** Add the `.conf` file to the
   webserver service's `configs/common/conf.d/` folder and merge the two variables from
   `LCP.json.snippet` into the webserver's `LCP.json` `env` section.
   - The log format uses `$tm_auth`, which the `.conf` file defines. If the variable
     arrives without the file, **nginx refuses to start** (`unknown "tm_auth" variable`)
     and the webserver goes into a restart loop. Never deploy the snippet on its own.
   - `LCP_WEBSERVER_NGINX_ACCESS_LOG_MODE=all` is required. The image's default is `off`,
     which writes no access logs at all.
   - Each log line is about twice as long as the default format. Check the effect on log
     volume before production.
2. **robots.txt.** In the Liferay site's robots.txt settings, add:
   ```
   User-agent: *
   Disallow: /_tm/
   ```
   Without this, the honeypot also catches well-behaved crawlers that follow every link.
3. **Honeypot link.** Put the contents of `honeypot-link.html` in a place that appears on
   every public page, such as a footer fragment or the theme's footer. It must be in the
   server-rendered HTML, not added by JavaScript.
4. **Beacon.** Build and deploy `client-extensions/traffic-beacon`. Global JS client
   extensions are not active by default: enable it for the public pages of each site
   (**Site Builder → Pages → configure the page set → JavaScript Client Extensions**,
   wording varies by DXP update). Requires a DXP 7.4 update with client extension support.
5. **Check.** Open a page in a browser and confirm the webserver logs show `tm=1` lines,
   `POST /_tm/b?t=load…` with status 204, and no errors in the webserver service log.

## Running the classifier

```bash
export TM_SALT='<random secret, 16+ characters, kept out of source control>'
./scripts/fetch-enrichment.sh data                       # weekly
./scripts/run-classifier.sh 2026-11-24 logs/2026-11-24   # one UTC day
```

Pass all of one day's files in one run: the honeypot and "no interaction all day"
signals are computed per UTC day. Input may be plain text or `.gz`.

Outputs, per UTC day and host: `daily_summary.csv` (page views and share per class),
`signals.csv`, `top_clients.csv` (top 50 per class) and `top_paths.csv`.
`--detail` adds `page_views.csv` with one row per page view; it is large and contains
personal data, so it is off by default.

## Dashboard

```bash
python3 scripts/build_report.py --in out --out report.html
```

`--in` can be repeated and is searched recursively, so one folder per day (as written by
`run-classifier.sh`) works. The result is a single HTML file with no external
dependencies: it opens offline and can be attached to an email. It contains only
aggregates, salted IP hashes and user agents. See `samples/sample-report.html`.

What it shows, for the last 7, 14 or 30 days (with change against the previous period
where the data covers it):

| Section | Question it answers |
|---|---|
| Human page views (headline) | How much real traffic does the site get, and is it growing? |
| Automated share | How much of the traffic is bots that do not identify themselves? |
| Backend time used by automation | How much of Liferay's page processing is spent on bots (capacity and cost)? |
| Identified bots and search engines | How much traffic comes from crawlers that announce themselves? |
| Uncertain (data quality) | Can the numbers be trusted? A rising share means the rules need tuning. |
| Page views per day, by class | When did bot traffic spike? (hover for each day's breakdown) |
| Humans vs automation share | Is the mix changing over time? |
| Where page processing time goes | Which classes cost the most backend time, and the average per page |
| Why page views were flagged | Which signals drive the classification |
| Pages most targeted by automation | What are bots after (search, product pages, ...)? |
| Top automated clients | Candidates for blocking or rate limiting (cloud provider, user agent, days seen) |
| Daily numbers | The same data as a table |

To rebuild the sample: run `samples/make_sample_logs.py` with an AWS `ip-ranges.json`,
then the classifier and `build_report.py`.

### Classes

| Class | Meaning |
|---|---|
| `human` | Passed the bot checks, no signed-in cookie |
| `signed_in` | Passed the bot checks and sent a Liferay session-state cookie |
| `uncertain` | Score 30–59 |
| `automated` | Score 60+, including clients that sent a signed-in cookie |
| `script_or_headless` | User agent of an HTTP library or headless browser |
| `declared_bot` | User agent says it is a bot, or claims a search engine that could not be verified |
| `verified_search_engine` | Search engine user agent confirmed by reverse and forward DNS |

Only `GET` responses with status 200 or 304 and an HTML content type count as page
views. Redirects, errors, assets, the beacon and the honeypot do not.

## How the main signals work

- **Client IP** is `$remote_addr`. Liferay Cloud's webserver already resolves it to the
  real client from `X-Forwarded-For` using the load balancer's address. The left end of
  `X-Forwarded-For` is written by the client and is never used.
- **Signed-in cookie** (`LFR_SESSION_STATE_…`) can be sent by anyone, so it only labels
  page views that already look human. It never excludes a request from the checks.
- **Beacon** match: the page's path and the beacon's path are both decoded once before
  comparing, so URLs with non-ASCII characters (for example Japanese) match.
- **Honeypot** applies to the IP *and* user agent that requested it, for that UTC day, so
  other people behind the same office or mobile network address are not flagged.
- **Search engine verification** (`--verify-dns`) first checks that reverse DNS works.
  If it does not, claims are counted as `declared_bot` instead of being called fake.

## Privacy

The logs contain IP addresses, URLs, user agents and language preferences, which can be
personal data. The summaries contain only salted IP hashes, which are still pseudonymous
personal data. Rotate `TM_SALT` (for example monthly) so that visitors cannot be linked
across longer periods, limit who can read the logs and outputs, and agree the retention
period with the customer's privacy contact.

## Validation status

Tested (November 2026):
- The `.conf` file and log format are accepted by `liferaycloud/nginx:1.31.0-6.8.0`
  (`nginx -t`), and nginx fails to start if the log format is deployed without the file.
- Simulated traffic through nginx with the same log format and real-IP settings,
  classified as expected: human visitors on English and Japanese pages, a spoofed
  Googlebot, a script sending a fake signed-in cookie, a signed-in browser, a person
  sharing an IP with a honeypot-hitting bot, and redirects and 404s.
- 200,000 lines with 40,000 distinct IPs and the AWS and Google Cloud ranges.

Not yet tested: deployment on a real Liferay Cloud environment, the beacon client
extension in a real DXP, and whether `LFR_SESSION_STATE_` is set only for signed-in
users and cleared at sign-out in the customer's DXP version.

The claim that the page-view selection matches Liferay's own anonymous page view rules
comes from the original package and has not been verified.
